package noteBook;

public class MainClass {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Login login=new Login();
		login.setTitle("My NoteBook");
	}
}
