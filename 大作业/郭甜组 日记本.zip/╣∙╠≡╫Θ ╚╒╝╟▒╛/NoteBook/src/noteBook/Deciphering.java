package noteBook;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
java.lang.Object

public class Deciphering {
	private int [] buffer;
	public  void  readFile(File file ) throws IOException{           //�������ļ�����
	    FileInputStream fin=new FileInputStream(file  );
	    InputStreamReader inReader=new InputStreamReader(fin,"utf-8");
	    BufferedReader bReader=new BufferedReader(inReader);
	    StringBuffer content=new StringBuffer();
	    String line=null;
	    while((line=bReader.readLine())!=null){
	        content.append(line);
	        content.append("\n");
	    }
	    bReader.close();
	    inReader.close();
	    fin.close();
	     buffer =new int [content.length()];
	   for (int i=0;i<content.length();i++)
	   {
		   buffer[i]= (content.charAt(i)-'a');
	   }
	    
	    //System.out.println(content);
	    
	}
	public  Deciphering(File file )throws  Exception
	{
		readFile(file );
	byte[] content =new byte[buffer.length];
		
		for (int i=0;i<buffer.length;i++)
		{
			content[i]=(byte)buffer[i];
		}
	
	String[] string =new String[buffer.length];
	for (int i=0;i<buffer.length;i++)
	{
		string[i]=new Byte("dhsghj").toString(content[i]);
	}
	}
}
