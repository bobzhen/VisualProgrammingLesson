package noteBook;
import java.io.*;
import java.lang.StringBuffer;

public class Encrypt{
	
	
public  StringBuffer readFile(File file ) throws IOException{           //�������ļ�����
    FileInputStream fin=new FileInputStream(file  );
    InputStreamReader inReader=new InputStreamReader(fin,"utf-8");
    BufferedReader bReader=new BufferedReader(inReader);
    StringBuffer content=new StringBuffer();
    String line=null;
    while((line=bReader.readLine())!=null){
        content.append(line);
        content.append("\n");
    }
    bReader.close();
    inReader.close();
    fin.close();
    file.delete();
    
    //System.out.println(content);
    return content;
}
public void writetoFile (int [] buffer,File file  )throws IOException
{
	 FileOutputStream fout =new  FileOutputStream(file  ,true);
	 for (int i=0;i<buffer.length;i++)
	 fout.write(buffer[i]);
	 fout.close();
}

    public Encrypt(File file  )throws Exception 
    {
    StringBuffer content = readFile(file );
    int  [] buffer =new int  [content.length()];
    for (int i=0;i<content.length();i++)
    {//content.setCharAt(i, (char)((int)content.charAt(i)+1));
    buffer[i]= (content.charAt(i)+'a');
    }
   
    writetoFile (buffer, file  );
   
    }
    

	
		
	

}
