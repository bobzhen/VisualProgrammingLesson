package noteBook;


import java.applet.*;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.TexturePaint;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;

import javax.swing.*;
import javax.swing.border.TitledBorder;

public class NoteBookEnglish extends JFrame implements ActionListener,ItemListener{
	JMenuBar menuBar;
	JMenu menu;
	JMenuItem open,save;
	JButton openButton,saveButton;
	JTextArea textArea;
	JTextField date;//���������
	BufferedImage img;
	Image img1=new ImageIcon("7.jpg").getImage();
	Graphics2D p;
	JPanel panel1,panel2,panel3;
	JRadioButton musicOn,musicOff;
	JComboBox day,wether;
	URL cb; 
	File f;                        
	AudioClip aau;
	String userName="";
	public NoteBookEnglish(String userName){
		this.userName=userName;
		initMenuBar();//���Ӳ˵���
		initInterface();//���ý���
		setVisible(true);
		setBounds(100,0,1024,700);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	}
	public void initMenuBar(){//���Ӳ˵���
		open=new JMenuItem("Open");
		save=new JMenuItem("Save");
		open.addActionListener(this);
		save.addActionListener(this);
		menu=new JMenu("File");
		menuBar=new JMenuBar();
		menuBar.setBackground(Color.pink);
		menu.add(open);
		menu.add(save);
		menuBar.add(menu);
		setJMenuBar(menuBar);
	}
	void initInterface(){
		initPanel1();
	    //panel2Ϊ���·�����壬��д�ռǵĵط�
		panel2=new JPanel(){
			 public void paint(Graphics g){
		        	setOpaque(false);               
		            //����һ������ͼ���BufferedImage
		            img=new BufferedImage(img1.getWidth(null),img1.getHeight(null),BufferedImage.TYPE_3BYTE_BGR);
		            p=img.createGraphics();
		            p.drawImage(img1,0,0,null);
		            p.dispose();
		            //׼�����Σ���������һ���������
		            Rectangle rectangle=new Rectangle(0,0,img1.getWidth(null),img1.getHeight(null));
		            TexturePaint tu=new TexturePaint(img,rectangle);
		            //�ô������������������������
		            p=(Graphics2D)g;   
		            p.setPaint(tu);
		            p.fillRect(0,0,this.getWidth(),this.getHeight());
		            super.paint(g);                 //���ø���Ļ��ƺ���
		        }
		};
		//panel2.setBackground(Color.pink);
		textArea=new JTextArea(30,50);
		textArea.setLineWrap(true);//�����Զ����й��� 
		textArea.setWrapStyleWord(true);//������в����ֹ��� 
		JScrollPane pane=new JScrollPane(textArea);
		panel2.add(pane);
		
		//panel3�����Ϸ��Ŀؼ������ռǵĿ�ͷ��ʽ
		panel3=new JPanel(){
			 public void paint(Graphics g){
		        	setOpaque(false);               
		            //����һ������ͼ���BufferedImage
		            img=new BufferedImage(img1.getWidth(null),img1.getHeight(null),BufferedImage.TYPE_3BYTE_BGR);
		            p=img.createGraphics();
		            p.drawImage(img1,0,0,null);
		            p.dispose();
		            //׼�����Σ���������һ���������
		            Rectangle rectangle=new Rectangle(0,0,img1.getWidth(null),img1.getHeight(null));
		            TexturePaint tu=new TexturePaint(img,rectangle);
		            //�ô������������������������
		            p=(Graphics2D)g;   
		            p.setPaint(tu);
		            p.fillRect(0,0,this.getWidth(),this.getHeight());
		            super.paint(g);                 //���ø���Ļ��ƺ���
		        }
		};
		panel3.setLayout(new FlowLayout());
		date=new JTextField(20);
		day=new JComboBox();
		day.addItem("Monday");
		day.addItem("Tuesday");
		day.addItem("Wednesday");
		day.addItem("Thursday");
		day.addItem("Friday");
		day.addItem("Saturday");
		day.addItem("Sunday");
		wether=new JComboBox();
		wether.addItem("sunny");
		wether.addItem("cloudy");
		wether.addItem("rainy");
		wether.addItem("snowny");
		Box box=Box.createHorizontalBox();
		box.add(new JLabel("date"));
		box.add(date);
		box.add(box.createHorizontalStrut(130));
		box.add(new JLabel("day"));
		box.add(day);
		box.add(box.createHorizontalStrut(130));
		box.add(new JLabel("weather"));
		box.add(wether);
		panel3.add(box);
		
		//��ִ���
		JSplitPane pane2=new JSplitPane(JSplitPane.VERTICAL_SPLIT,panel3,panel2);
		JSplitPane pane1=new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,panel1,pane2);
		pane1.setResizeWeight(0.7);
		pane2.setResizeWeight(0.3);
		add(pane1);
	}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==open||e.getSource()==openButton){//�򿪹�ȥ���ռ�
			JFileChooser fileDialog=new JFileChooser();
			int state=fileDialog.showOpenDialog(this);
			if(state==JFileChooser.APPROVE_OPTION){
				if(textArea.getText()!=null&&!textArea.getText().equals("")){
					if(JOptionPane.showConfirmDialog(this, "��ǰ�����������ݣ��Ƿ�����༭��","ȷ�϶Ի���",JOptionPane.YES_NO_OPTION)==JOptionPane.NO_OPTION){
						return;
					}
				}
				textArea.setText(null);
				try{
					//File file=fileDialog.getCurrentDirectory();
					File file=fileDialog.getSelectedFile();
					FileReader reader=new FileReader(file);
					BufferedReader in=new BufferedReader(reader);
					String string="";
					while((string=in.readLine())!=null){
						textArea.append(string+"\n");
					}
					reader.close();
					in.close();
				}catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		}else if(e.getSource()==save||e.getSource()==saveButton){//���浱ǰ�ռ�
			File file1=new File("C:\\Users\\Administrator\\Desktop\\NoteBookUSER\\"+userName);
			//�������ļ��в����ڣ��ȴ����ļ���
			if(!file1.exists()){
				try {
					file1.mkdir();
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
			
			JFileChooser fileDialog=new JFileChooser();
			fileDialog.setCurrentDirectory(file1);
			int state=fileDialog.showSaveDialog(this);
			if(state==JFileChooser.APPROVE_OPTION){
				try {
					File dirFile=fileDialog.getSelectedFile();
					FileWriter fileWriter=new FileWriter(dirFile);
					BufferedWriter out=new BufferedWriter(fileWriter);
					out.write(date.getText()+"   "+day.getSelectedItem()+"   "+wether.getSelectedItem());
					out.newLine();
					out.write(textArea.getText());
					out.close();
					fileWriter.close();
				} catch (Exception e2) {
					e2.printStackTrace();
				}
			}
		}
		
	}
	void initPanel1(){
		//panel1Ϊ��ߵ�panel
		panel1=new JPanel(){
	        public void paint(Graphics g){
	        	setOpaque(false);               
	            //����һ������ͼ���BufferedImage
	            img=new BufferedImage(img1.getWidth(null),img1.getHeight(null),BufferedImage.TYPE_3BYTE_BGR);
	            p=img.createGraphics();
	            p.drawImage(img1,0,0,null);
	            p.dispose();
	            //׼�����Σ���������һ���������
	            Rectangle rectangle=new Rectangle(0,0,img1.getWidth(null),img1.getHeight(null));
	            TexturePaint tu=new TexturePaint(img,rectangle);
	            //�ô������������������������
	            p=(Graphics2D)g;   
	            p.setPaint(tu);
	            p.fillRect(0,0,this.getWidth(),this.getHeight());
	            super.paint(g);                 //���ø���Ļ��ƺ���
	        }
	    };
	    //���ñ����Ŀؼ�
	    ButtonGroup setBackground=new ButtonGroup();
	    JRadioButton background[]=new JRadioButton[4];
	    JPanel backPanel=new JPanel();
	    String backgroundName[]={"background1","background2","background3","background4"};
	    Box backgroundBox=Box.createVerticalBox();
	    for(int i=0;i<background.length;i++){
	    	background[i]=new JRadioButton(backgroundName[i]);
	    	background[i].setOpaque(false);
	    	background[i].addItemListener(this);
	    	setBackground.add(background[i]);
	    	backgroundBox.add(background[i]);
	    	backgroundBox.add(Box.createVerticalStrut(10));
	    }
	    backPanel.add(backgroundBox);
	    backPanel.setOpaque(false);
	    backPanel.setBorder(BorderFactory.createTitledBorder(
	    		null, "reset background", TitledBorder.LEADING,
	    		TitledBorder.TOP, new Font("Dialog", Font.BOLD, 12),
	    		new Color(51, 51, 51)));
	    //�������ֵĿؼ�
	    JPanel music=new JPanel();
	    ButtonGroup musicGroup=new ButtonGroup();
	    musicOn=new JRadioButton("ON");
	    musicOff=new JRadioButton("OFF");
	    musicOn.addItemListener(this);
	    musicOff.addItemListener(this);
	    musicOn.setOpaque(false);
	    musicOff.setOpaque(false);
	    musicGroup.add(musicOn);
	    musicGroup.add(musicOff);
	    music.add(musicOn);
	    music.add(musicOff);
	    music.setOpaque(false);
	    music.setBorder(BorderFactory.createTitledBorder(
	    		null, "Music", TitledBorder.LEADING,
	    		TitledBorder.TOP, new Font("Dialog", Font.BOLD, 12),
	    		new Color(51, 51, 51)));
	    //��ť
	    openButton=new JButton("open my previous diary");
	    saveButton=new JButton("save the current diary");
	    Box panel1Box=Box.createVerticalBox();
	    panel1Box.add(Box.createVerticalStrut(20));
	    panel1Box.add(music);
	    panel1Box.add(Box.createVerticalStrut(30));
	    panel1Box.add(backPanel);
	    panel1Box.add(Box.createVerticalStrut(170));
	    panel1Box.add(openButton);
	    panel1Box.add(Box.createVerticalStrut(10));
	    panel1Box.add(saveButton);
	    panel1.add(panel1Box);
	    
	    openButton.addActionListener(this);
	    saveButton.addActionListener(this);
	    
	}
	public void itemStateChanged(ItemEvent e) {
		JRadioButton tempButton=(JRadioButton)e.getSource();   
		if(tempButton.isSelected()){
			String text=tempButton.getText();
			if(text.equals("ON")){
				String imagePath=System.getProperty("user.dir")+"/Music/";
				try {        
					f = new File(imagePath+"�峿.wav");           
					cb = f.toURL();                 
					aau = Applet.newAudioClip(cb);  
					aau.play();//ѭ������ aau.play() ���� aau.stop()ֹͣ����              //aau.loop();         
				} catch (Exception eee) {             
					eee.printStackTrace();          
				}  
			}else if(text.equals("OFF")){
				aau.stop();
			}else if(text.equals("background1")){
				img1=new ImageIcon("8.jpg").getImage();
				panel1.repaint();
				panel2.repaint();
				panel3.repaint();
			}else if(text.equals("background2")){
				img1=new ImageIcon("2.jpg").getImage();
				panel1.repaint();
				panel2.repaint();
				panel3.repaint();
			}else if(text.equals("background3")){
				img1=new ImageIcon("11.jpg").getImage();
				panel1.repaint();
				panel2.repaint();
				panel3.repaint();
			}else if(text.equals("background4")){
				img1=new ImageIcon("4.jpg").getImage();
				panel2.repaint();
				panel1.repaint();
				panel3.repaint();
			}
		}
	}
}

